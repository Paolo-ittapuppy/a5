

Assignment 5: Encrypted Graphical User Interface

This assignment includes the following starter files:

* __a5.py__: Use this file as the main module for your program.
* __NaClProfile.py__: Use this file as your module that is a subclass of Profile.py.
* __NaClDSEncoder.py__: Use this file to provide helper functions for encrypting.

Please visit the course website for a detailed overview of the assignment.
